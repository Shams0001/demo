import React, { useState } from 'react'
import { Link, NavLink } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';
import { useEffect } from 'react';
 const SideBar=()=>{
    const navigate=useNavigate();
    const [loggedIn,setLog]=useState(false);
    useEffect(()=>{
        if(localStorage.getItem("userid"))
        {
            setLog(true);
        }
    })
    return<>
    <div className="sidebar">
        
        <nav className="sidenav">
            <ul>
                <li>
                   {/* <button onClick={()=>{
                    navigate("/landing")
                   }}>Home</button> */}
                   <NavLink to="/">Home</NavLink>

                </li>
                <li>
                {
                loggedIn? <NavLink to="/favourite">Favourite</NavLink> : <Link to="/signin">Login</Link>
                    
                 
                
                }

                </li>
                <li>
                <NavLink to="/about">About</NavLink>

                </li>
               
                <li>
                <NavLink to="/entertainment">Entertainment</NavLink>

                </li>
                <li>
                <NavLink to="/music">Music</NavLink>

                </li>
                <li>
                <NavLink to="/sports">Sports</NavLink>

                </li>
            </ul>
        </nav>
    </div>
    </>
 }
 export default SideBar;