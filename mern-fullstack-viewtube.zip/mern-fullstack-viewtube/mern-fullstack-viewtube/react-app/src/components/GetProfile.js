import { useState,useEffect } from 'react';
import axios from 'axios';
import config from '../config'


const GetProfile = ()=>{

const [profile,setProfile] = useState([]);
useEffect(()=>{
    let token = document.cookie.split('=')[1];
  const {user} = axios.get(config.GetProfileURL,{
    headers: {
        "Content-Type": "application/json",
        "Authorization": token
    }, withCredentials:true
  });
   console.log({user});
   setProfile(user)
    console.log(profile);
    
     
},[])

    return(
        <>

          {profile.firstName};
        </>
    )

}

export default GetProfile;